package Vaccines.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Vaccines.model.VaccinesEntry;

@WebServlet(urlPatterns = "/Vaccines", loadOnStartup = 1)
public class Vaccines extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Vaccines() {
		super();
	}

	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		List<VaccinesEntry> entries = new ArrayList<VaccinesEntry>();
		entries.add(new VaccinesEntry("Pfizer/BioNTech", 2, 21, 10000, 10000));
		entries.add(new VaccinesEntry("Johnson & Johnson", 1, 0, 5000, 5000));

		getServletContext().setAttribute("entries", entries);
	}

	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<VaccinesEntry> entries = (List<VaccinesEntry>) getServletContext().getAttribute("entries");

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println("<html><head><title>Vaccine</title></head><body>");
		// out.println("<h2>Vaccines</h2><br>");

		out.println(
				"<tr><h3><a href='NewVaccine'>New Vaccine | </a>" + "<a href='NewDoses'> New Doses</a></h3></tr><br>");

		out.println("<table border='1'>");

		out.println("<th>Vaccine</th>");
		out.println("<th>Doses Required</th>");
		out.println("<th>Days Between Doses	</th>");
		out.println("<th>Total Doses Received</th>");
		out.println("<th>Total Doses Left</th>");
		out.println("<th></th>");

		for (VaccinesEntry entry : entries) {
			out.println("<tr>");
			out.println("<td>" + entry.getVaccineName() + " </td>");
			out.println("<td>" + entry.getDosesRequired() + "</td>");
			out.println("<td>" + entry.getDaysBetweenDoses() + "</td>");
			out.println("<td>" + entry.getTotalDosesReceived() + "</td>");
			out.println("<td>" + entry.getTotalDosesLeft() + "</td>");
			out.println("<td><a href='EditVaccine?fname=frank&id=" + entry.getId() + "'>Edit</a> |");

			out.println("</td>");
			out.println("</tr>");
		}
		out.println("</table>");
		out.println("</body></html>");
	}

}