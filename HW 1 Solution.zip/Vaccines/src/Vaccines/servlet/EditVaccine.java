package Vaccines.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Vaccines.model.VaccinesEntry;

@WebServlet("/EditVaccine")
public class EditVaccine extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EditVaccine() {
		super();
	}

	@SuppressWarnings("unchecked")
	private VaccinesEntry getEntry(int id) {
		List<VaccinesEntry> entries = (List<VaccinesEntry>) getServletContext().getAttribute("entries");

		for (VaccinesEntry entry : entries)
			if (entry.getId() == id)
				return entry;
		return null;
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		VaccinesEntry entry = getEntry(Integer.parseInt(id));

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println("<form action='EditVaccine' method='post'>");
		out.println("<input type='hidden' name='id' value='" + id + "'>");
		out.println("Name: <input type='text' name='vaccineName' value='" + entry.getVaccineName() + "'><br>");
		out.println("Doses Required: " + "<select name='dosesRequired'>" + "<option value='1'>1</option>"
				+ "<option value='2'>2</option>" + "</select></br>");
		out.println("Days Between Doses: <input type='text' name='daysBetweenDoses' value='"
				+ entry.getDaysBetweenDoses() + "'><br>");

		out.println("<button type='submit'>Save</button></form>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		VaccinesEntry entry = getEntry(Integer.parseInt(request.getParameter("id")));
		entry.setVaccineName(request.getParameter("vaccineName"));
		entry.setDosesRequired(Integer.parseInt(request.getParameter("dosesRequired")));
		entry.setDaysBetweenDoses(Integer.parseInt(request.getParameter("daysBetweenDoses")));

		response.sendRedirect("Vaccines");
	}
}
