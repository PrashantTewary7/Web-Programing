package Vaccines.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Vaccines.model.VaccinesEntry;

@WebServlet("/NewVaccine")
public class NewVaccine extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public NewVaccine() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		StringBuilder html = new StringBuilder();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println("<form action='NewVaccine' method='post'>");

		out.println("Name: <input type='text' name='vaccineName'><br>");
		out.println("Doses Required: " + "<select name='dosesRequired'>" + "<option value='1'>1</option>"
				+ "<option value='2'>2</option>" + "</select></br>");
		out.println("Days Between Doses: <input type='text' name='daysBetweenDoses'><br>");

		out.println("<button type='submit'>Add</button></form>");
	}

	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String vaccineName = request.getParameter("vaccineName");
		int dosesRequired = (Integer.parseInt(request.getParameter("dosesRequired")));
		int daysBetweenDoses = (Integer.parseInt(request.getParameter("daysBetweenDoses")));
		VaccinesEntry entry = new VaccinesEntry(vaccineName, dosesRequired, daysBetweenDoses, daysBetweenDoses,
				daysBetweenDoses);

		List<VaccinesEntry> entries = (List<VaccinesEntry>) getServletContext().getAttribute("entries");
		entries.add(entry);

		response.sendRedirect("Vaccines");
	}
}