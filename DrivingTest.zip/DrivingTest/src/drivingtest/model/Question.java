package drivingtest.model;

public class Question {

	public String description;
	public String answerA;
	public String answerB;
	public String answerC;
	public int correctAnswer;

	public Question(String description, String answerA, String answerB, String answerC, int correctAnswer) {
		this.description = description;
		this.answerA = answerA;
		this.answerB = answerB;
		this.answerC = answerC;
		this.correctAnswer = correctAnswer;
	}

	public String getDescription() {
		return description;
	}

	public String getAnswerA() {
		return answerA;
	}

	public int getCorrectAnswer() {
		return correctAnswer;
	}

	public String getAnswerB() {
		return answerB;
	}

	public String getAnswerC() {
		return answerC;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setAnswerA(String answerA) {
		this.answerA = answerA;
	}

	public void setCorrectAnswer(int correctAnswer) {
		this.correctAnswer = correctAnswer;
	}

	public void setAnswerB(String answerB) {
		this.answerB = answerB;

	}

	public void setAnswerC(String answerC) {
		this.answerC = answerC;

	}
}
