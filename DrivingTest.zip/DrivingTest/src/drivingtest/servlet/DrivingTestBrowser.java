package drivingtest.servlet;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import drivingtest.model.Question;

@WebServlet(urlPatterns = "/DrivingTestBrowser", loadOnStartup = 1)
public class DrivingTestBrowser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public DrivingTestBrowser() {
		super();
	}

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		List<Question> entries = new ArrayList<>();

		try {
			Scanner in;
			in = new Scanner(new File(getServletContext().getRealPath("/WEB-INF/DrivingTest.txt")));
			while (in.hasNextLine()) {
				Question question = new Question(null, null, null, null, 0);
				question.setDescription(in.nextLine());
				question.setAnswerA(in.nextLine());
				question.setAnswerB(in.nextLine());
				question.setAnswerC(in.nextLine());
				question.setCorrectAnswer(Integer.parseInt(in.nextLine()));
				entries.add(question);
				in.nextLine();
			}
			in.close();
		} catch (FileNotFoundException e) {
			throw new ServletException(e);
		}
		getServletContext().setAttribute("entries", entries);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("index") != null) {
			request.setAttribute("index", Integer.parseInt(request.getParameter("index")));
		} else {
			request.setAttribute("index", "0");
		}
		request.getRequestDispatcher("/DrivingQuestion.jsp").forward(request, response);
	}
}