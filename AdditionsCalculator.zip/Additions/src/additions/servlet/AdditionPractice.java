package additions.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

@WebServlet("/AdditionPractice")
public class AdditionPractice extends HttpServlet {
        private static final long serialVersionUID = 1L;
        
        private static Random r;
        
        private static int n1, n2;

    public AdditionPractice() {
        super();
        r = new Random();
    }

        protected void doGet(HttpServletRequest request, HttpServletResponse response) 
        		throws ServletException, IOException {
                response.setContentType("text/html");
                
                n1 = r.nextInt(10);
                n2 = r.nextInt(10);
                
                response.getWriter().print("<form method='post' action='AdditionPractice' > "
                                + "<input type='text' value= " + n1 + " /> " + " + "
                                + "<input type='text' value= " + n2 + " /> " + "   = "
                                + "<input name='res' type='text'/>"
                                + " <input type='submit'/> </form>");
        }

        protected void doPost(HttpServletRequest request, HttpServletResponse response)
                        throws ServletException, IOException {
                response.setContentType("text/html");
                
                int ans = (n1+n2);
                
                int userans = Integer.parseInt(request.getParameter("res"));
                
                response.getWriter().println("Correct Answer :"+ans);
                
                if(ans==userans) {
                        response.getWriter().print("Your Answer "+userans+" is correct.");
                }else {
                        response.getWriter().println("Your Answer "+userans+" is incorrect.");
                        response.getWriter().print("<form method='get' action='AdditionPractice'> "
                                        + "<input type='submit' value='Try Again!'> "
                                        + "</form>");
                }      
        }
}